# QuartetoAPP

Este aplicativo foi criado para o projeto final da disciplina de Desenvolvimento Mobile. Este projeto tem como finalidade demonstrar o conhecimento adquirido sobre linguagem Kotlin e a ferramento Android Studio.

# Circo Quarteto Elegante

Nosso aplicativo foi criado com o objetivo de auxiliar na venda de ingressos de um circo.

# Equipe Quarteto Elegante

Beatriz Bramont Oliveira | RA: 2402004
Giovanna Petrilli Venditti | RA: 2401830
Isadora Cristyne de Lima Silva | RA: 2401838
Vinicios de Lima Basteiro | RA: 2402096
