# Meu App Android (Kotlin)

Este é um projeto Android simples feito em Kotlin.

## Estrutura
- `app/`: Módulo principal da aplicação
- `src/main/`: Código-fonte e recursos
- `MainActivity.kt`: Tela principal

## Como rodar
Abra no Android Studio e execute em um emulador ou dispositivo real.